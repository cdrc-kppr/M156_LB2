import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Treeup here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Treeup extends Actor
{
    /**
     * Act - do whatever the Treeup wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        move();
        checkForWall();
    }    
    
    
    /**
     * Lässt den Stamm mit einer bestimmten Geschwindigkeit vorwärts bewegen.
     */
    private void move()
    {
        setLocation(getX()-6, getY());
    }
    
    /**
     * Überprüft ob der Stamm gerade an einer Wand angekommen ist.
     */
    private void checkForWall()
    {
        if (getX() == 0) 
        {
            getWorld().removeObject(this);
        }
    }
    
}

