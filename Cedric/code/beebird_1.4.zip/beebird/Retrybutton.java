import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class Retrybutton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Retrybutton extends Actor
{
    /**
     * Act - do whatever the Retrybutton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        hoverit();
        if(Greenfoot.mouseClicked(this)) 
        {
            Greenfoot.setWorld(new Startscreen());
        }
    }  
    
    public void hoverit()
    {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        
        if (mouse != null) {
            
            setImage("retrybutton.png");
            List objects = getWorld().getObjectsAt(mouse.getX(), mouse.getY(), Retrybutton.class);
            for (Object object : objects)
            {
                if (object == this)
                {
                    
                    setImage("retrybutton2.png");
                }
            }
        }
    }
}
