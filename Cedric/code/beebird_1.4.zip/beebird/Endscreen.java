import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Endscreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Endscreen extends World
{

    /**
     * Konstruktor für Objekte im Endscreen.
     * 
     */
    public Endscreen()
    {    
        super(800, 600, 1); 
        prepare();
        //Greenfoot.start();
    }
    
    /**
     * Bereitet die Welt für den Programmstart vor.
     */
    private void prepare()
    {
       Retrybutton retrybutton = new Retrybutton();
       addObject(retrybutton, 400, 325);
    }
}
