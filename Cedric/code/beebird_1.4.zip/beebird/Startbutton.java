import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class Startbutton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Startbutton extends Actor
{
    /**
     * Act - do whatever the Startbutton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        hoverit();
        if(Greenfoot.mouseClicked(this)) Greenfoot.setWorld(new Spielwelt());
    }    
    
    public void hoverit()
    {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        
        if (mouse != null) {
            
            setImage("startbutton.png");
            List objects = getWorld().getObjectsAt(mouse.getX(), mouse.getY(), Startbutton.class);
            for (Object object : objects)
            {
                if (object == this)
                {
                    
                    setImage("startbutton2.png");
                }
            }
        }
    }
}
