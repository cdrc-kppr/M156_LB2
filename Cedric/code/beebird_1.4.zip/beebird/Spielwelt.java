import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Spielwelt here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spielwelt extends World
{
    public int height = Greenfoot.getRandomNumber(50);
    public int cannotspawn = 1;
    public int bushcounter = 1;
    public java.lang.String bushname = "";
    public int bushcounter2 = 1;
    public java.lang.String bushname2 = "";
    public int poscounter = 0;
    public int allow = 1;
    
    /**
     * Constructor for objects of class Spielwelt.
     * 
     */
    public Spielwelt()
    {    
        super(800, 600, 1); 
        setPaintOrder(Bee.class, Bush.class, Treeup.class, Treedown.class);
        prepare();
    }
    
    /**
     * 
     */
    public void act()
    {
        randomHeight();
        spawner();
        createBush();
    }
    
    /**
     * Lässt die Objekte(Gegner) erscheinen. Ausserdem kann nur ein neues Objekt erscheinen,
     * wenn kein weiteres Objek besteht.
     */
    private void spawner()
    {
        if (cannotspawn == 0)    
        {
            Treeup treeup = new Treeup();
            addObject(treeup, 800, 100 - height);
            
            Treedown treedown = new Treedown();
            addObject(treedown, 800, 550 - height);
            
            Honey honey = new Honey();
            addObject(honey, 800, 300 - height);
            
            cannotspawn ++;
            
        }        
        
    }
        
    /**
     * 
     */
    public void canNotSpawn(int torf)
    {
        cannotspawn = cannotspawn - torf;
    }
    
    /**
     * 
     */
    private void randomHeight()
    {
        height = Greenfoot.getRandomNumber(50);
    }
    
    /**
     * 
     */
    private void createBush()
    {
       if (Greenfoot.getRandomNumber(10) == 1)
       {
           Bush bush = new Bush();
           addObject(bush, 800, 30 - height); 
           
           Bush bush2 = new Bush();
           addObject(bush2, 800, 570 + height);
       }
    }
    
    /**
     * Stopt die Spielwelt
     */
    public void stopPlay()
    {
        Greenfoot.stop();
    }
    
    /**
     * Bereitet die Welt für den Programmstart vor.
     */
    private void prepare()
    {
       Bee bee = new Bee();
       addObject(bee, 250, 300); 
       
       Treeup treeup = new Treeup();
       addObject(treeup, 800, 100 - height); 
       
       Treedown treedown = new Treedown();
       addObject(treedown, 800, 550 - height);
       
       Honey honey = new Honey();
       addObject(honey, 800, 300 - height);
       
       while(bushcounter < 30) 
       {
           bushname = "bush"+bushcounter;
           bushname2 = "bush"+bushcounter2;
                      
           Bush bushname = new Bush();
           addObject(bushname, 800 - poscounter, 30 - (Greenfoot.getRandomNumber(50)));
           
           Bush bushname2 = new Bush();
           addObject(bushname2, 800 - poscounter, 570 + (Greenfoot.getRandomNumber(50)));
           
           bushcounter ++;
           poscounter = poscounter + (Greenfoot.getRandomNumber(3) * 20);
       }
    }
  
}
