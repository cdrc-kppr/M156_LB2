import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bee here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bee extends Actor
{
    private int gravity;
    public int posint;
    public int cannotspawn = 1;
    public int turnint = 0;
    
    /**
     * Act - do whatever the Bee wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        applyGravity();
        applyFlyMotion();
        checkForJump();
        checkCollision();
        
    }    
    
    
    /**
     * Wendet die Gravitation auf die Biene an, so dass sie nach einem 
     * Fügelschlag wieder nach unten sinkt.
     */
    private void applyGravity()
    {
        gravity--;
        setLocation(getX(), getY() - gravity);
    }
    
    private void applyFlyMotion()
    {
        turnint = getY() - posint;
        setRotation(turnint / 3);
    }
    
    /**
     * Prüft, ob eine Taste auf der Tastatur gedrückt wurde, und
     * reagiert, falls dies zutrifft.     
     */
    private void checkForJump()
    {
        if (Greenfoot.isKeyDown("space"))
        {
            gravity = 15;
            posint = getY();
        }
    }
    
    /**
     * Prüft, ob die Biene einen Stamm berührt hat.
     * Wenn ja, stribt sie.
     */
    private void checkCollision()
    {
        Treeup a = (Treeup) getOneIntersectingObject(Treeup.class);
        Treedown b = (Treedown) getOneIntersectingObject(Treedown.class);
        if (a != null | b != null) 
        {
            Greenfoot.setWorld(new Endscreen());
        }
        
        Honey c = (Honey) getOneIntersectingObject(Honey.class);
        if (c != null) 
        {
            //getWorld().removeObject(Honey);
        }
    }
}
