import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Spielwelt here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spielwelt extends World
{
    public int height = Greenfoot.getRandomNumber(50);
    
    /**
     * Constructor for objects of class Spielwelt.
     * 
     */
    public Spielwelt()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        prepare();
        setPaintOrder();
    }
    
    /**
     * 
     */
    public void act()
    {
        
    }
    
    /**
     * Bereitet die Welt für den Programmstart vor.
     */
    private void prepare()
    {
       Bee bee = new Bee();
       addObject(bee, 200, 300); 
       
       Treeup treeup = new Treeup();
       addObject(treeup, 700, 100 - height); 
       
       Treedown treedown = new Treedown();
       addObject(treedown, 680, 550 - height);
    }
  
}
