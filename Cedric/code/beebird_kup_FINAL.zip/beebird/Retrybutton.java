import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Der Retrybutton lässt das Spiel neustarten.
 * 
 * @author KUP 
 * @version 2.0
 */
public class Retrybutton extends Actor
{
    /**
     * Führt alle befehle aus die für das Spiel benötigt werden.
     */
    public void act() 
    {
        hoverit();
        if(Greenfoot.mouseClicked(this)) 
        {
            Greenfoot.playSound("click.mp3");
            Greenfoot.setWorld(new Startscreen());
        }
    }  
    
    /**
     * Sogtdafür das der User erkennt wenn er denn Button "hovert", also mit der Maus darüberfährt.
     * Das Bild ändert sich.
     */
    public void hoverit()
    {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        
        if (mouse != null) {
            
            setImage("retrybutton.png");
            List objects = getWorld().getObjectsAt(mouse.getX(), mouse.getY(), Retrybutton.class);
            for (Object object : objects)
            {
                if (object == this)
                {
                    
                    setImage("retrybutton2.png");
                }
            }
        }
    }
}
