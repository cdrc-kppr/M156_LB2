import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Der Treedown (Baum unten) stellt den einen Teil des Hindernisses dar, welches man überwinden muss.
 * 
 * @author KUP 
 * @version 2.0
 */
public class Treedown extends Actor
{
    /**
     * Führt alle befehle aus die für das Spiel benötigt werden.
     */
    public void act() 
    {
        move();
        checkForWall();
    }    
    
    /**
     * Lässt den Stamm mit einer bestimmten Geschwindigkeit vorbeiziehen.
     */
    private void move()
    {
        setLocation(getX()-6, getY());
    }
    
    /**
     * Überprüft ob der Stamm gerade an einer Wand angekommen ist.
     */
    private void checkForWall()
    {
        if (getX() == 0) 
        {
            Spielwelt spielwelt = (Spielwelt)getWorld();
            spielwelt.canNotSpawn(1);
            getWorld().removeObject(this);
        }
    }
}
