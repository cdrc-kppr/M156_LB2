import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Die Spielwelt wird angezeigt wärend das Spiel läuft.
 * 
 * @author KUP 
 * @version 2.0
 */
public class Spielwelt extends World
{
    public int height = Greenfoot.getRandomNumber(50);
    public int cannotspawn = 1;
    public int bushcounter = 1;
    public java.lang.String bushname = "";
    public int bushcounter2 = 1;
    public java.lang.String bushname2 = "";
    public int poscounter = 0;
    public int allow = 1;
    public int score = 0;
    public int point;
    
    /**
     * Konstruktor für Objekte in der Spielwelt
     */
    public Spielwelt()
    {    
        super(800, 600, 1); 
        setPaintOrder(Border.class, Score.class, Bee.class, Bush.class, Treeup.class, Treedown.class);
        prepare();
    }
    
    /**
     * Führt alle befehle aus die für das Spiel benötigt werden.
     */
    public void act()
    {
        randomHeight();
        spawner();
        createBush();
        showScore();
    
    }
    
    /**
     * Lässt die Objekte(Gegner) erscheinen. Ausserdem kann nur ein neues Objekt erscheinen,
     * wenn kein weiteres Objek besteht.
     */
    private void spawner()
    {
        if (cannotspawn == 0)    
        {
            Treeup treeup = new Treeup();
            addObject(treeup, 800, 100 - height);
            
            Treedown treedown = new Treedown();
            addObject(treedown, 800, 550 - height);
            
            Honey honey = new Honey();
            addObject(honey, 800, 300 - height);
            
            cannotspawn ++;
            
        }        
        
    }
        
    /**
     * Überprüft ob gerade ein Baumstamm/Honig existiert oder nicht.
     */
    public void canNotSpawn(int torf)
    {
        cannotspawn = cannotspawn - torf;
    }
    
    /**
     * Kreiert eine zufällige Zahl für die Höhe. So ist jeder Baumstamm unterschiedlich hoch.
     */
    private void randomHeight()
    {
        height = Greenfoot.getRandomNumber(50);
    }
    
    /**
     * Erstellt an zufälligen Höhen und in einer bestimmten Warscheinichkeit, Büsche oben und untem am Screen.
     * (So sieht es aus als würde die Biene durch einen Wald fliegen)
     */
    private void createBush()
    {
       if (Greenfoot.getRandomNumber(10) == 1)
       {
           Bush bush = new Bush();
           addObject(bush, 800, 30 - height); 
       }
       
       if (Greenfoot.getRandomNumber(10) == 1)
       {
           Bush bush2 = new Bush();
           addObject(bush2, 800, 570 + height);
       }
    }
    
    /**
     * Zeigt den Punktestand
     */
    public void showScore()
    {
        showText("" + score, 402, 90); 
    }
    
    /**
     * Zählt die Punkte hoch
     */
    public void addScore(int point)
    {
        score = score + point;
    }
    
    /**
     * Bereitet die Welt für den Programmstart vor.
     */
    private void prepare()
    {
       Bee bee = new Bee();
       addObject(bee, 250, 300); 
       
       Treeup treeup = new Treeup();
       addObject(treeup, 800, 100 - height); 
       
       Treedown treedown = new Treedown();
       addObject(treedown, 800, 550 - height);
       
       Honey honey = new Honey();
       addObject(honey, 800, 300 - height);
       
       Border border = new Border();
       addObject(border, 400, 300);
       
       Score score = new Score();
       addObject(score, 400, 70);
       
       while(bushcounter < 30) 
       {
           bushname = "bush"+bushcounter;
           bushname2 = "bush"+bushcounter2;
                      
           Bush bushname = new Bush();
           addObject(bushname, 800 - poscounter, 30 - (Greenfoot.getRandomNumber(50)));
           
           Bush bushname2 = new Bush();
           addObject(bushname2, 800 - poscounter, 570 + (Greenfoot.getRandomNumber(50)));
           
           bushcounter ++;
           poscounter = poscounter + (Greenfoot.getRandomNumber(3) * 20);
       }
    }
  
}
