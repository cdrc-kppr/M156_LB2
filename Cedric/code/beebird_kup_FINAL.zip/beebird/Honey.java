import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Der Honig sorgt für den Score. Wenn ein Honig eingesammelt wird geht
 * der Punktestand nach oben.
 * 
 * @author KUP 
 * @version 2.0
 */
public class Honey extends Actor
{
    /**
     * Führt alle befehle aus die für das Spiel benötigt werden.
     */
    public void act() 
    {
        move();
        checkForWall();
        checkBee();
    }    
    
    /**
     * Lässt den Honig mit einer bestimmten Geschwindigkeit vorbeiziehen.
     */
    private void move()
    {
        setLocation(getX()-6, getY());
    }
    
    /**
     * Überprüft ob der Honig gerade an einer Wand angekommen ist.
     */
    private void checkForWall()
    {
        if (getX() == 0) 
        {
            getWorld().removeObject(this);
        }
    }
    
    /**
     * Prüft, ob die Biene den Honig berührt hat.
     * Wenn ja, verschwindet er und man erhält einen Pluspunkt.
     */
    private void checkBee()
    {
        Bee c = (Bee) getOneIntersectingObject(Bee.class);
        if (c != null) 
        {
            Spielwelt spielwelt = (Spielwelt)getWorld();
            spielwelt.addScore(1);
            
            Greenfoot.playSound("coin.mp3");
            
            getWorld().removeObject(this);
        }
    }
}
