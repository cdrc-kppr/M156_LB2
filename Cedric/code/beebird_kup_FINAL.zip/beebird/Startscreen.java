import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Der Startscreen wird beim Sielstart angezeigt.
 * 
 * @author KUP 
 * @version 2.0
 */
public class Startscreen extends World
{
    GreenfootSound backMusic = new GreenfootSound("back_music.mp3");
    
    /**
     * Konstruktor für Objekte im Startscreen
     * 
     */
    public Startscreen()
    {    
        super(800, 600, 1); 
        prepare();
        Greenfoot.start();
        backMusic.playLoop();
    }
    
    /**
     * Stopt die Musik
     */
    public void stopMusic()
    {
        backMusic.stop();
    }
    
    
    /**
     * Bereitet die Welt für den Programmstart vor.
     */
    private void prepare()
    {
       Startbutton startbutton = new Startbutton();
       addObject(startbutton, 400, 325);
       
    }
}
