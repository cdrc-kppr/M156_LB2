import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Die Border verdeckt die Ränder. So sieht man die spawnenden Objekte nicht und es macht das ganze 
 * Spiel etwas übersichtlicher.
 * 
 * @author KUP 
 * @version 2.0
 */
public class Border extends Actor
{
    /**
     * Führt alle befehle aus die für das Spiel benötigt werden.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
