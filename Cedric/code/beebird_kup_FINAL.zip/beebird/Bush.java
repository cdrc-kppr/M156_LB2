import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Der Bush bewegt sich oben unt unten am Screen. Er sort für ein Gefühl
 * der Vorwärtsbewegung.
 * 
 * @author KUP 
 * @version 2.0
 */
public class Bush extends Actor
{
    /**
     * Führt alle befehle aus die für das Spiel benötigt werden.
     */
    public void act() 
    {
        move();
        checkForWall();
    }    
    
    /**
     * Lässt den Busch mit einer bestimmten Geschwindigkeit vorbeiziehen.
     */
    private void move()
    {
        setLocation(getX()-6, getY());
    }
    
    /**
     * Überprüft ob der Busch gerade an einer Wand angekommen ist.
     */
    private void checkForWall()
    {
        if (getX() == 0) 
        {
            getWorld().removeObject(this);
        }
    }
}
