import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Der Score wird wärend des Spiels angezeigt.
 * 
 * @author KUP 
 * @version 2.0
 */
public class Score extends Actor
{
    public static int score;
    
    /**
     * Führt alle befehle aus die für das Spiel benötigt werden.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
