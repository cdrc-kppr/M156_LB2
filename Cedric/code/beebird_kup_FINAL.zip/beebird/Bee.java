import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Die Biene fliegt durch die Welt. Sie wird vom Spieler gesteuert.
 * 
 * @author KUP 
 * @version 2.0
 */
public class Bee extends Actor
{
    private int gravity;
    public int posint;
    public int cannotspawn = 1;
    public int turnint = 0;
    public int soundcount = 1;
    /**
     * Führt alle befehle aus die für das Spiel benötigt werden.
     */
    public void act() 
    {
        applyGravity();
        applyFlyMotion();
        checkForJump();
        checkCollision();
        
    }    
    
    
    /**
     * Wendet die Gravitation auf die Biene an, so dass sie nach einem 
     * Fügelschlag wieder nach unten sinkt.
     */
    private void applyGravity()
    {
        gravity--;
        setLocation(getX(), getY() - gravity);
    }
    
    /**
     * Sorgt dafür das sich die Biene mit steigender Höhe nach oben und mit sinkender Höhe nach unten neigt.
     */
    private void applyFlyMotion()
    {
        turnint = getY() - posint;
        setRotation(turnint / 3);
    }
    
    /**
     * Prüft, ob eine Taste auf der Tastatur gedrückt wurde, und
     * reagiert, falls dies zutrifft.     
     */
    private void checkForJump()
    {
        if (Greenfoot.isKeyDown("space"))
        {
            gravity = 15;
            while(soundcount == 1) 
            {
                Greenfoot.playSound("flap.mp3");
                soundcount ++;
            }
            posint = getY();
        }else{ 
            soundcount = 1;
        }
    }
    
    /**
     * Prüft, ob die Biene einen Stamm berührt hat.
     * Wenn ja, stribt sie.
     */
    private void checkCollision()
    {
        Treeup a = (Treeup) getOneIntersectingObject(Treeup.class);
        Treedown b = (Treedown) getOneIntersectingObject(Treedown.class);
        if (a != null | b != null) 
        {
            Greenfoot.playSound("fail.mp3");
            Greenfoot.setWorld(new Endscreen());
        }
        
        if (getY() == 0 | getY() == 599) 
        {
            Greenfoot.playSound("fail.mp3");
            Greenfoot.setWorld(new Endscreen());
        }
    }
}
