import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Der Endscreen wird angezeigt wenn die Biene stirbt.
 * 
 * @author KUP 
 * @version 2.0
 */
public class Endscreen extends World
{
    public static int score;
    
    /**
     * Konstruktor für Objekte im Endscreen.
     * 
     */
    public Endscreen()
    {    
        super(800, 600, 1); 
        prepare();        
    }
    
   
    
    /**
     * Bereitet die Welt für den Programmstart vor.
     */
    private void prepare()
    {
       Retrybutton retrybutton = new Retrybutton();
       addObject(retrybutton, 400, 325);
                       
    }
}
