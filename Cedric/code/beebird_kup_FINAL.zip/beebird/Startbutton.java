import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Der Startbutton startet das Spiel.
 * 
 * @author KUP 
 * @version 2.0
 */
public class Startbutton extends Actor
{
    /**
     * Führt alle befehle aus die für das Spiel benötigt werden.
     */
    public void act() 
    {
        hoverit();
        if(Greenfoot.mouseClicked(this) | Greenfoot.isKeyDown("space")) 
        {
            Startscreen startscreen = (Startscreen)getWorld();
            startscreen.stopMusic();
            Greenfoot.playSound("click.mp3");
            Greenfoot.setWorld(new Spielwelt());
        }
    }    
    
    /**
     * Sogtdafür das der User erkennt wenn er denn Button "hovert", also mit der Maus darüberfährt.
     * Das Bild ändert sich.
     */
    public void hoverit()
    {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        
        if (mouse != null) {
            
            setImage("startbutton.png");
            List objects = getWorld().getObjectsAt(mouse.getX(), mouse.getY(), Startbutton.class);
            for (Object object : objects)
            {
                if (object == this)
                {
                    
                    setImage("startbutton2.png");
                }
            }
        }
    }
}
