import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

//bush is at the top and at the bottom of the screen. It should create a movinc effect.
// Aut. ANTSAV
// Versiom 1.5

public class Bush extends Actor
{
     //create all Comands for the game
    public void act() 
    {
        move();
        checkForWall();
    }    
    
   //speed of the bush
    private void move()
    {
        setLocation(getX()-6, getY());
    }
    
    //check if it touches the wall (x=0)
    private void checkForWall()
    {
        if (getX() == 0) 
        {
            getWorld().removeObject(this);
        }
    }
}
