import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

// Honey is here to higher the score if the user is able to catch it
// Aut. ANTSAV
// Versiom 1.5


public class Honey extends Actor
{
    //create all Comands for the game
    public void act() 
    {
        move();
        checkForWall();
        checkBee();
    }    
    
    //speed of the honey
    private void move()
    {
        setLocation(getX()-6, getY());
    }
    
    //check if there is a collision with the wall (x=0)
    private void checkForWall()
    {
        if (getX() == 0) 
        {
            getWorld().removeObject(this);
        }
    }
    
    //check if bee touches honey, if yes, add score and honey disapperas 
    private void checkBee()
    {
        Bee c = (Bee) getOneIntersectingObject(Bee.class);
        if (c != null) 
        {
            Spielwelt spielwelt = (Spielwelt)getWorld();
            spielwelt.addScore(1);
            
            Greenfoot.playSound("coin.mp3");
            
            getWorld().removeObject(this);
        }
    }
}
