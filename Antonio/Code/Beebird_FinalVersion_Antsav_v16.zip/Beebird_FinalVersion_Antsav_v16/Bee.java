import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

// The Main character, the bee
// Aut. ANTSAV
// Versiom 1.5

public class Bee extends Actor
{
    private int gravity;
    public int posint;
    public int cannotspawn = 1;
    public int turnint = 0;
   //create all Comands for the game
    public void act() 
    {
        applyGravity();
        applyFlyMotion();
        checkForJump();
        checkCollision();
    }    
    
    //apply gravity to the bee, after she jumps she start falling back down
    private void applyGravity()
    {
        gravity--;
        setLocation(getX(), getY() - gravity);
    }
    
    //let the bee look in the direction she is flying
    private void applyFlyMotion()
    {
        turnint = getY() - posint;
        setRotation(turnint / 3);
    }
    
    //jump if "space" is pressed
    private void checkForJump()
    {
        if (Greenfoot.isKeyDown("space"))
        {
            gravity = 12;
            posint = getY();
        }
    }
    
   //die if tree is touched
    private void checkCollision()
    {
        Treeup a = (Treeup) getOneIntersectingObject(Treeup.class);
        Treedown b = (Treedown) getOneIntersectingObject(Treedown.class);
        if (a != null | b != null) 
        {
            Greenfoot.setWorld(new Endscreen());
        }
        
        if (getY() == 0 | getY() == 599) 
        {
            Greenfoot.setWorld(new Endscreen());
        }
    }
}
