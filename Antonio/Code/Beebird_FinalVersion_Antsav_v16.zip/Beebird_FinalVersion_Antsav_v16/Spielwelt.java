import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

// Main World
// Aut. ANTSAV
// Versiom 1.5

public class Spielwelt extends World
{
    public int height = Greenfoot.getRandomNumber(50);
    public int cannotspawn = 1;
    public int bushcounter = 1;
    public java.lang.String bushname = "";
    public int bushcounter2 = 1;
    public java.lang.String bushname2 = "";
    public int poscounter = 0;
    public int allow = 1;
    public int score = 0;
    public int point;
    
    //Konstruktor
    public Spielwelt()
    {    
        super(800, 600, 1); 
        setPaintOrder(Border.class, Score.class, Bee.class, Bush.class, Treeup.class, Treedown.class);
        prepare();
    }
    
    //all comands for the game
    public void act()
    {
        randomHeight();
        spawner();
        createBush();
        showScore();
    
    }
    
   //show score
    public void showScore()
    {
        showText("" + score, 402, 90); 
    }
    
    //count points
    public void addScore(int point)
    {
        score = score + point;
    }
    
    //generate Enemeys. only one enemy allowed
    private void spawner()
    {
        if (cannotspawn == 0)    
        {
            Treeup treeup = new Treeup();
            addObject(treeup, 800, 100 - height);
            
            Treedown treedown = new Treedown();
            addObject(treedown, 800, 550 - height);
            
            Honey honey = new Honey();
            addObject(honey, 800, 300 - height);
            
            cannotspawn ++;
            
        }        
        
    }
        
    //check if there is honey or trees
    public void canNotSpawn(int trueorfalse)
    {
        cannotspawn = cannotspawn - trueorfalse;
    }
    
   //create random nomber for height. So that all Trees are diffrent.
    private void randomHeight()
    {
        height = Greenfoot.getRandomNumber(50);
    }
    
    //create bushes
    private void createBush()
    {
       if (Greenfoot.getRandomNumber(10) == 1)
       {
           Bush bush = new Bush();
           addObject(bush, 800, 30 - height); 
       }
       
       if (Greenfoot.getRandomNumber(10) == 1)
       {
           Bush bush2 = new Bush();
           addObject(bush2, 800, 570 + height);
       }
    }
    
   //prepare for start of game
    private void prepare()
    {
       Bee bee = new Bee();
       addObject(bee, 250, 300); 
       
       Treeup treeup = new Treeup();
       addObject(treeup, 800, 100 - height); 
       
       Treedown treedown = new Treedown();
       addObject(treedown, 800, 550 - height);
       
       Honey honey = new Honey();
       addObject(honey, 800, 300 - height);
       
       Border border = new Border();
       addObject(border, 400, 300);
       
       Score score = new Score();
       addObject(score, 400, 70);
       
       while(bushcounter < 30) 
       {
           bushname = "bush"+bushcounter;
           bushname2 = "bush"+bushcounter2;
                      
           Bush bushname = new Bush();
           addObject(bushname, 800 - poscounter, 30 - (Greenfoot.getRandomNumber(50)));
           
           Bush bushname2 = new Bush();
           addObject(bushname2, 800 - poscounter, 570 + (Greenfoot.getRandomNumber(50)));
           
           bushcounter ++;
           poscounter = poscounter + (Greenfoot.getRandomNumber(3) * 20);
       }
    }
  
}
