import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

//score is shown during all the game
// Aut. ANTSAV
// Versiom 1.5

public class Score extends Actor
{
    public static int score;
    
    /**
     * Führt alle befehle aus die für das Spiel benötigt werden.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
