import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FlappyBeeWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FlappyBeeWorld extends World
{

    /**
     * Constructor for objects of class FlappyBeeWorld.
     * 
     */
    public FlappyBeeWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1, false); 
        // create FlappyBee
        FlappyBeee flappy = new FlappyBeee();
        
        // Add flappy to the world
        addObject(flappy, 100, getHeight()/2);
        
    }
}
