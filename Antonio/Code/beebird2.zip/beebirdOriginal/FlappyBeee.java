import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FlappyBeee here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FlappyBeee extends Actor
{
    int dy = 0;
    int g = 1;
    int BOOST_SPEED = -10;
    
    /**
     * Act - do whatever the FlappyBeee wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        setLocation( getX(), getY() + dy );
        
        //if user press space, jump upward
        if (Greenfoot.isKeyDown("space") == true) {
            dy = BOOST_SPEED;
        }
        
        //if FlappyBeee drops out of world, game over
        if (getY() > getWorld().getHeight()) {
            GameOver gameOverpic = new GameOver();
            getWorld().addObject(gameOverpic, getWorld().getWidth()/2, getWorld().getHeight()/2);
            Greenfoot.stop();
        }
        dy = dy + g;
    
    }    
    
}
