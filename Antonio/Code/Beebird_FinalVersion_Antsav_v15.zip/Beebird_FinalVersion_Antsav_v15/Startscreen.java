import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

// show startscreen is shown when the game starts
// Aut. ANTSAV
// Versiom 1.5

public class Startscreen extends World
{
    //constructor for the startscreen
    public Startscreen()
    {    
        super(800, 600, 1); 
        prepare();
        Greenfoot.start();
    }
    
    //prepare world for start of the game
    private void prepare()
    {
       Startbutton startbutton = new Startbutton();
       addObject(startbutton, 400, 325);
       
    }
}
