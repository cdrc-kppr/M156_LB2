import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;

// retry button is here to restart the game
// Aut. ANTSAV
// Versiom 1.5

public class Retrybutton extends Actor
{
    //create all Comands for the game
    public void act() 
    {
        hoverit();
        if(Greenfoot.mouseClicked(this)) 
        {
            Greenfoot.playSound("click.mp3");
            Greenfoot.setWorld(new Startscreen());
        }
    }  
    
    //change image if mouse is on the button
    public void hoverit()
    {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        
        if (mouse != null) {
            
            setImage("retrybutton.png");
            List objects = getWorld().getObjectsAt(mouse.getX(), mouse.getY(), Retrybutton.class);
            for (Object object : objects)
            {
                if (object == this)
                {
                    
                    setImage("retrybutton2.png");
                }
            }
        }
    }
}
