import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;

//startbutton to start the game
// Aut. ANTSAV
// Versiom 1.5

public class Startbutton extends Actor
{
    //all comands to start the game
    // Aut. ANTSAV
    // Versiom 1.5

    public void act() 
    {
        hoverit();
        if(Greenfoot.mouseClicked(this) | Greenfoot.isKeyDown("space")) 
        {
            Startscreen startscreen = (Startscreen)getWorld();
            Greenfoot.playSound("click.mp3");
            Greenfoot.setWorld(new Spielwelt());
        }
    }    
    
    //change image if mouse is on the button
    public void hoverit()
    {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        
        if (mouse != null) {
            setImage("startbutton.png");
            List objects = getWorld().getObjectsAt(mouse.getX(), mouse.getY(), Startbutton.class);
            for (Object object : objects)
            {
                if (object == this)
                {
                    
                    setImage("startbutton2.png");
                }
            }
        }
    }
}
