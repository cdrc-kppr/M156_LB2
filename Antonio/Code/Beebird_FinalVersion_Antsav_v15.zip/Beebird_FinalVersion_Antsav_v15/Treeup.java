import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

// Upper Tree, which is a part of the enemy of the Bee
// Aut. ANTSAV
// Versiom 1.5

public class Treeup extends Actor
{
    //create all Comands for the game
    public void act() 
    {
        move();
        checkForWall();
    }    
    
    
    //speed of the tree
    private void move()
    {
        setLocation(getX()-6, getY());
    }
    
    //check if it touches the wall (x=0)
    private void checkForWall()
    {
        if (getX() == 0) 
        {
            Spielwelt spielwelt = (Spielwelt)getWorld();
            spielwelt.canNotSpawn(1);
            getWorld().removeObject(this);
        }
    }
    
}

