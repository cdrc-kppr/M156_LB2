import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

// Endscore is shown after the bee died
// Aut. ANTSAV
// Versiom 1.5

public class Endscreen extends World
{
    public static int score;
    
    //konstructor for endscreen
    public Endscreen()
    {    
        super(800, 600, 1); 
        prepare();        
    }
    
    //prepare world for start of the game
    private void prepare()
    {
       Retrybutton retrybutton = new Retrybutton();
       addObject(retrybutton, 400, 325);
                       
    }
}
